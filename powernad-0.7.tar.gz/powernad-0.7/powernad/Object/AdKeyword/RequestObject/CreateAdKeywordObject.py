class CreateAdKeywordObject:
    def __init__(self, keyword):

        self.bidAmt = None
        self.customerId = None
        self.keyword = keyword
        self.useGroupBidAmt = None
        self.userLock = None