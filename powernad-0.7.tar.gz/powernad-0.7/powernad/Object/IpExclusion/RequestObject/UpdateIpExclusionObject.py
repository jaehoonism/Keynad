class UpdateIpExclusionObject:
    def __init__(self, filterIp, ipFilterId):
        self.filterIp = filterIp
        self.ipFilterId = ipFilterId
        self.memo = None