class CreateIpExclusionObject:
    def __init__(self, filterIp):
        self.filterIp = filterIp
        self.memo = None