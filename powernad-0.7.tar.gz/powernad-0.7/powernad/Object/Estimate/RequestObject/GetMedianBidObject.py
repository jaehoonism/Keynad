class GetMedianBidObject:
    def __init__(self, device, period, keys):
        self.device = device
        self.period = period
        self.items = keys