class UpdateLabelObject:
    def __init__(self, nccLabelId):
        self.color = None
        self.name = None
        self.nccLabelId = nccLabelId