class UpdateAdKeywordObject:

    def __init__(self, nccAdgroupId, nccKeywordId):

        self.bidAmt = None
        self.links = None
        self.nccAdgroupId = nccAdgroupId
        self.nccKeywordId = nccKeywordId
        self.useGroupBidAmt = None
        self.userLock = None