class CreateMasterReportObject:
    def __init__(self, item, fromTime):
        self.item = item
        self.fromTime = fromTime