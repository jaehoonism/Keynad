class GetPerformanceObject:
    def __init__(self, device, keywordplus, key, bids):
        self.device = device
        self.keywordplus = keywordplus
        self.key = key
        self.bids = bids