class GetAvgPositionBidObject:
    def __init__(self, device, KeyAndPositonObject):
        self.device = device
        self.items = KeyAndPositonObject