class KeyAndPositionObject:
    def __init__(self, key, position):
        self.key = key
        self.position = position