class CreateStatReportObject:
    def __init__(self, reportTp, statDt):
        self.reportTp = reportTp
        self.statDt = statDt
        #self.customerId = 1109868