class UpdateLabelRefObject:
    def __init__(self, customerId, nccLabelId, refId, refTp):
        self.customerId = customerId
        self.enable = True
        self.nccLabelId = nccLabelId
        self.refId = refId
        self.refTp = refTp