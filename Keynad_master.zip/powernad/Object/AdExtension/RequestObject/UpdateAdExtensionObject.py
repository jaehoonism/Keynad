class UpdateAdExtensionObject:

    def __init__(self, nccAdExtensionId, schedule=None, userLock = None):
        self.nccAdExtensionId = nccAdExtensionId
        self.schedule = schedule
        self.userLock = userLock